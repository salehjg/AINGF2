/************************************************************
**	AINGF-V2 FIRMWARE
**	
**		- 16BIT FIFO IN
**		- 16BIT FIFO OUT
**		- IFCLK PIN AS OUTPUT(INTERNAL CLOCK MODE)
**		- Vendor Requests Added.
**
**
*************************************************************/






#pragma NOIV                    // Do not generate interrupt vectors
//-----------------------------------------------------------------------------
//   File:      slave.c
//   Contents:  Hooks required to implement USB peripheral function.
//              Code written for FX2 REVE 56-pin and above.
//              This firmware is used to demonstrate FX2 Slave FIF
//              operation.
//   Copyright (c) 2003 Cypress Semiconductor All rights reserved
//-----------------------------------------------------------------------------
#include "fx2.h"
#include "fx2regs.h"
#include "fx2sdly.h"            // SYNCDELAY macro

//-----------------------------------------------------------------------------
// Constants
//-----------------------------------------------------------------------------

#define I3C_CLK			PA0
#define I3C_USBFX_D_OUT	PA1
#define I3C_USBFX_D_IN	((IOA & 1<<3)>>3)
#define DUMMY_BIT		0

#define LED_ALL         (bmBIT0 | bmBIT1 | bmBIT2 | bmBIT3)


#define VR_UPLOAD		0xa2 	// 
#define VR_RENUM	    0xa3 	// 
#define VR_I2C_RATE    	0xa4 	// 
#define VR_3LED			0xa5	// Update 3 LEDS
#define VR_CMD			0xa6	// CUSTOM AINGF REQ
#define VR_FLUSH		0xa7 	// CUSTOM AINGF REQ

#define EP0BUFF_SIZE	0x40


extern BOOL GotSUD;             // Received setup data flag
extern BOOL Sleep;
extern BOOL Rwuen;
extern BOOL Selfpwr;


BYTE buff_special[64];
BYTE buff_special_depth = 0;

BYTE Configuration;             // Current configuration
BYTE AlternateSetting;          // Alternate settings
static WORD xdata LED_Count = 0;
static BYTE xdata LED_Status = 0;

// EZUSB FX2 PORTE is not bit-addressable...
//-----------------------------------------------------------------------------
// Task Dispatcher hooks
// The following hooks are called by the task dispatcher.
//-----------------------------------------------------------------------------
void LED_Off (BYTE LED_Mask);
void LED_On (BYTE LED_Mask);

//-----------------------------------------------------------------------------
// Task Dispatcher hooks
//   The following hooks are called by the task dispatcher.
//-----------------------------------------------------------------------------
void TD_Init( void )
{ // Called once at startup

  CPUCS = 0x10; // CLKSPD[1:0]=10, for 48MHz operation, output CLKOUT
//  FIFOPINPOLAR |= 0x03;

		OEE = 0x0B; //Config PortE.0 and 1 and 3 as outputs
		IOE = IOE & (~(0x0B));
		OEA = 0x03; //Config I2c_LIKE BUS IO
		IOA = IOA & (~(0x03));

  PINFLAGSAB = 0x08;			// FLAGA - EP6FF
  SYNCDELAY;
  PINFLAGSCD = 0xE0;			// FLAGD - EP2EF
  SYNCDELAY;
  PORTACFG |= 0x80;
  IFCONFIG = 0xe3; // for async? for sync?   0xE3  for internal 48mhz                   0x43 for external clock

  // IFCLKSRC=1   , FIFOs executes on internal clk source 
  // xMHz=1       , 48MHz operation
  // IFCLKOE=1    ,Drive IFCLK pin signal at 48MHz
  // IFCLKPOL=0   , Don't invert IFCLK pin signal from internal clk
  // ASYNC=0      , master samples synchronous
  // GSTATE=0     , Don't drive GPIF states out on PORTE[2:0], debug WF
  // IFCFG[1:0]=11, FX2 in slave FIFO mode


  // Registers which require a synchronization delay, see section 15.14
  // FIFORESET        FIFOPINPOLAR
  // INPKTEND         OUTPKTEND
  // EPxBCH:L         REVCTL
  // GPIFTCB3         GPIFTCB2
  // GPIFTCB1         GPIFTCB0
  // EPxFIFOPFH:L     EPxAUTOINLENH:L
  // EPxFIFOCFG       EPxGPIFFLGSEL
  // PINFLAGSxx       EPxFIFOIRQ
  // EPxFIFOIE        GPIFIRQ
  // GPIFIE           GPIFADRH:L
  // UDMACRCH:L       EPxGPIFTRIG
  // GPIFTRIG
  
  // Note: The pre-REVE EPxGPIFTCH/L register are affected, as well...
  //      ...these have been replaced by GPIFTC[B3:B0] registers


  
 

  // EP4 and EP8 are not used in this implementation...
                   
  EP2CFG = 0xA0;                //out 512 bytes, 4x, bulk
  SYNCDELAY;                    
  EP6CFG = 0xE0;                // in 512 bytes, 4x, bulk
  SYNCDELAY;              
  EP4CFG = 0x02;                //clear valid bit
  SYNCDELAY;                     
  EP8CFG = 0x02;                //clear valid bit
  SYNCDELAY;   

  SYNCDELAY;
  FIFORESET = 0x80;             // activate NAK-ALL to avoid race conditions
  SYNCDELAY;                    // see TRM section 15.14
  FIFORESET = 0x02;             // reset, FIFO 2
  SYNCDELAY;                    // 
  FIFORESET = 0x04;             // reset, FIFO 4
  SYNCDELAY;                    // 
  FIFORESET = 0x06;             // reset, FIFO 6
  SYNCDELAY;                    // 
  FIFORESET = 0x08;             // reset, FIFO 8
  SYNCDELAY;                    // 
  FIFORESET = 0x00;             // deactivate NAK-ALL


  // handle the case where we were already in AUTO mode...
  // ...for example: back to back firmware downloads...
  SYNCDELAY;                    // 
  EP2FIFOCFG = 0x00;            // AUTOOUT=0, WORDWIDE=1
  
  // core needs to see AUTOOUT=0 to AUTOOUT=1 switch to arm endp's
  
  SYNCDELAY;                    // 
  EP2FIFOCFG = 0x11;            // AUTOOUT=1, WORDWIDE=was zero when 0x010 , with value of 0x11 WordWIDE is one! (16bits)
  
  SYNCDELAY;                    // 
  EP6FIFOCFG = 0x0D;            // AUTOIN=1, ZEROLENIN=1, WORDWIDE= was zero when 0x0C , now its one!

  SYNCDELAY;

  
}

void TD_Poll( void )
{ // Called repeatedly while the device is idle

  // ...nothing to do... slave fifo's are in AUTO mode...
  
  
}

BOOL TD_Suspend( void )          
{ // Called before the device goes into suspend mode
   return( TRUE );
}

BOOL TD_Resume( void )          
{ // Called after the device resumes
   return( TRUE );
}

//-----------------------------------------------------------------------------
// Device Request hooks
//   The following hooks are called by the end point 0 device request parser.
//-----------------------------------------------------------------------------
BOOL DR_GetDescriptor( void )
{
   return( TRUE );
}

BOOL DR_SetConfiguration( void )   
{ // Called when a Set Configuration command is received
  
  if( EZUSB_HIGHSPEED( ) )
  { // ...FX2 in high speed mode
    EP6AUTOINLENH = 0x02;
    SYNCDELAY;
    EP8AUTOINLENH = 0x02;   // set core AUTO commit len = 512 bytes
    SYNCDELAY;
    EP6AUTOINLENL = 0x00;
    SYNCDELAY;
    EP8AUTOINLENL = 0x00;
  }
  else
  { // ...FX2 in full speed mode
    EP6AUTOINLENH = 0x00;
    SYNCDELAY;
    EP8AUTOINLENH = 0x00;   // set core AUTO commit len = 64 bytes
    SYNCDELAY;
    EP6AUTOINLENL = 0x40;
    SYNCDELAY;
    EP8AUTOINLENL = 0x40;
  }
      
  Configuration = SETUPDAT[ 2 ];
  return( TRUE );        // Handled by user code
}

BOOL DR_GetConfiguration( void )   
{ // Called when a Get Configuration command is received
   EP0BUF[ 0 ] = Configuration;
   EP0BCH = 0;
   EP0BCL = 1;
   return(TRUE);          // Handled by user code
}

BOOL DR_SetInterface( void )       
{ // Called when a Set Interface command is received
   AlternateSetting = SETUPDAT[ 2 ];
   return( TRUE );        // Handled by user code
}

BOOL DR_GetInterface( void )       
{ // Called when a Set Interface command is received
   EP0BUF[ 0 ] = AlternateSetting;
   EP0BCH = 0;
   EP0BCL = 1;
   return( TRUE );        // Handled by user code
}

BOOL DR_GetStatus( void )
{
   return( TRUE );
}

BOOL DR_ClearFeature( void )
{
   return( TRUE );
}

BOOL DR_SetFeature( void )
{
   return( TRUE );
}

WORD I3C_transact_word(WORD dat2send)
{
	int ii=0;
	WORD dat=0;
	
	I3C_USBFX_D_OUT = DUMMY_BIT;
	I3C_CLK=1;
	I3C_CLK=0;
	
	for(ii=15;ii>=0;ii--)
	{
		/*	if(ii>7)
		{
			if((dat2send>>ii) & 1)
			{	I3C_USBFX_D_OUT = 1;}
			else
			{	I3C_USBFX_D_OUT = 0;}

			I3C_CLK=1;
			I3C_CLK=0;
			dat = dat | (I3C_USBFX_D_IN << ii);
		}
		else
		{*/
			if((dat2send>>ii) & 1)
			{	I3C_USBFX_D_OUT = 1;}
			else
			{	I3C_USBFX_D_OUT = 0;}

			I3C_CLK=1;
			I3C_CLK=0;
			dat = dat | (I3C_USBFX_D_IN << ii);
		/*}*/
	}
	I3C_USBFX_D_OUT = DUMMY_BIT;
	I3C_CLK=1;
	I3C_CLK=0;
	
	return dat;
}

BOOL DR_VendorCmnd( void )
{

	WORD		len,bc;
//	WORD		ChipRev;
	WORD i;
	int ii;
	BYTE val;
	
	//============================

	// NOTE: PORT_E IS NOT BIT ADDRESSABLE!
	
	
	

	/*
		I2C_LK_BUS_CLK = PA.0 = OUTPUT
		I2C_LK_BUS_D0  = PA.1 = OUTPUT
		I2C_LK_BUS_D1  = PA.3 = INPUT


		#define I3C_CLK			PA0
		#define I3C_USBFX_D_OUT	PA1
		#define I3C_USBFX_D_IN	PA3



	*/
	
	
	
	switch(SETUPDAT[1])
	{ //TPM handle new commands

		case VR_3LED:
  	  	{
			val = SETUPDAT[2];	
			IOE = 0x00;
			if(val&0x1) IOE = 0x01; //turn LED1 ON GRN
			if(val&0x2) IOE = 0x02; //turn LED1 ON Yellow
			if(val&0x8) IOE = 0x08; //turn LED1 ON RED
			
		}			
		break;

		
						// SETUPDAT[4] CAN BE ODD OR EVEN, BUT SMALLER OR EQUAL TO 32.
						// byte[0]:LS-BYTE     byte[1]:MS-BYTE
		case VR_CMD:	// ON EACH CUSTOM_REQ, ONLY MAXIMUM COUNT OF 32 I3C_PAYLOAD CAN BE TRANSMITED.
  	  	{
			buff_special_depth = SETUPDAT[4] * 2; //how many bytes to issue I3C for...  
												  // ((SETUPDAT[4])) should be smaller than 32
			
			
			EP0BCL = 0X40; //ARM TO RECIEVE DATA -- DUMMY VALUE WRITE 
			while(EP0CS & bmEPBUSY);//WAIT FOR DATA ARRIVAL
			val = SETUPDAT[2];	//COMMAND OPCODE
			//-------------------------------------------
			for(i = 0 ; i < buff_special_depth ; i+=2) // 0<buff_special_depth<64
			{
				//bc is unsigned short
				bc = I3C_transact_word(       ( (*(EP0BUF+i+1  ))<<8 ) | ( (*(EP0BUF+i  )) )         ); //example:    byte[0]:LS-BYTE     byte[1]:MS-BYTE
				buff_special[i] = bc & 0xFF;
				buff_special[i+1] = (bc>>8)&0xFF;
			}
			//-------------------------------------------
		}			
		break;
		/*
		case VR_LEDS:
			val = SETUPDAT[2];
 		    if(val & 0x01)  dum=D2ON;
			else			dum=D2OFF;
 		    if(val & 0x02)  dum=D3ON;
			else			dum=D3OFF;
 		    if(val & 0x04)  dum=D4ON;
			else			dum=D4OFF;
 		    if(val & 0x08)  dum=D5ON;
			else			dum=D5OFF;
		break;

		// Set the I2C bus rate. Install a jumper plug between P8-37 and P8-39 to see the green LED
		case VR_I2C_RATE:
			val = SETUPDAT[2];		// wValueL indicates bus speed
			if(val==0x00)
			{
				I2CTL &= ~bm400KHZ;	// 0: 100 KHz
				IOA = 0x10;			// Green LED OFF
			}
			else
				{
				I2CTL |= bm400KHZ;	// nonzero: 400 KHz
				IOA = 0x00;			// Green LED ON
				}
		break;

		case VR_RENUM:
			
					EP0CS |= bmHSNAK; // Acknowledge handshake phase of device request
					EZUSB_Delay(1000);
					EZUSB_Discon(TRUE);		// renumerate until setup received
			break;
		*/
		case VR_UPLOAD:
		{
			len = buff_special_depth;
			while(len)					// Move requested data through EP0IN 
				{						// one packet at a time.
               	while(EP0CS & bmEPBUSY);
					if(len < EP0BUFF_SIZE) // 64 BYTES
						bc = len;
					else
						bc = EP0BUFF_SIZE;
				
					{
						for(i=0; i<bc; i++)
							*(EP0BUF+i) = buff_special[i] ;
						//EEPROMRead(addr,(WORD)bc,(WORD)EP0BUF);
					}
					EP0BCH = 0;
					EP0BCL = (BYTE)bc; // Arm endpoint with # bytes to transfer
					len -= bc;
				}
		}
		break;



		case VR_FLUSH:
		{
			  SYNCDELAY;
			  FIFORESET = 0x80;             // activate NAK-ALL to avoid race conditions
			  SYNCDELAY;                    // see TRM section 15.14
			  FIFORESET = 0x02;             // reset, FIFO 2
			  SYNCDELAY;                    // 
			  FIFORESET = 0x04;             // reset, FIFO 4
			  SYNCDELAY;                    // 
			  FIFORESET = 0x06;             // reset, FIFO 6
			  SYNCDELAY;                    // 
			  FIFORESET = 0x08;             // reset, FIFO 8
			  SYNCDELAY;                    // 
			  FIFORESET = 0x00;             // deactivate NAK-ALL
		}
		break;

		
	}
	return(FALSE); // no error; command handled OK

}

//-----------------------------------------------------------------------------
// USB Interrupt Handlers
//   The following functions are called by the USB interrupt jump table.
//-----------------------------------------------------------------------------

// Setup Data Available Interrupt Handler
void ISR_Sudav( void ) interrupt 0
{
   GotSUD = TRUE;         // Set flag
   EZUSB_IRQ_CLEAR( );
   USBIRQ = bmSUDAV;      // Clear SUDAV IRQ
}

// Setup Token Interrupt Handler
void ISR_Sutok( void ) interrupt 0
{
   EZUSB_IRQ_CLEAR( );
   USBIRQ = bmSUTOK;      // Clear SUTOK IRQ
}

void ISR_Sof( void ) interrupt 0
{
   EZUSB_IRQ_CLEAR( );
   USBIRQ = bmSOF;        // Clear SOF IRQ
}

void ISR_Ures( void ) interrupt 0
{
   if ( EZUSB_HIGHSPEED( ) )
   {
      pConfigDscr = pHighSpeedConfigDscr;
      pOtherConfigDscr = pFullSpeedConfigDscr;
   }
   else
   {
      pConfigDscr = pFullSpeedConfigDscr;
      pOtherConfigDscr = pHighSpeedConfigDscr;
   }
   
   EZUSB_IRQ_CLEAR( );
   USBIRQ = bmURES;       // Clear URES IRQ
}

void ISR_Susp( void ) interrupt 0
{
   Sleep = TRUE;
   EZUSB_IRQ_CLEAR( );
   USBIRQ = bmSUSP;
}

void ISR_Highspeed( void ) interrupt 0
{
   if ( EZUSB_HIGHSPEED( ) )
   {
      pConfigDscr = pHighSpeedConfigDscr;
      pOtherConfigDscr = pFullSpeedConfigDscr;
   }
   else
   {
      pConfigDscr = pFullSpeedConfigDscr;
      pOtherConfigDscr = pHighSpeedConfigDscr;
   }

   EZUSB_IRQ_CLEAR( );
   USBIRQ = bmHSGRANT;
}
void ISR_Ep0ack( void ) interrupt 0
{
}
void ISR_Stub( void ) interrupt 0
{
}
void ISR_Ep0in( void ) interrupt 0
{
}
void ISR_Ep0out( void ) interrupt 0
{
}
void ISR_Ep1in( void ) interrupt 0
{
}
void ISR_Ep1out( void ) interrupt 0
{
}
void ISR_Ep2inout( void ) interrupt 0
{
}
void ISR_Ep4inout( void ) interrupt 0
{
}
void ISR_Ep6inout( void ) interrupt 0
{
}
void ISR_Ep8inout( void ) interrupt 0
{
}
void ISR_Ibn( void ) interrupt 0
{
}
void ISR_Ep0pingnak( void ) interrupt 0
{
}
void ISR_Ep1pingnak( void ) interrupt 0
{
}
void ISR_Ep2pingnak( void ) interrupt 0
{
}
void ISR_Ep4pingnak( void ) interrupt 0
{
}
void ISR_Ep6pingnak( void ) interrupt 0
{
}
void ISR_Ep8pingnak( void ) interrupt 0
{
}
void ISR_Errorlimit( void ) interrupt 0
{
}
void ISR_Ep2piderror( void ) interrupt 0
{
}
void ISR_Ep4piderror( void ) interrupt 0
{
}
void ISR_Ep6piderror( void ) interrupt 0
{
}
void ISR_Ep8piderror( void ) interrupt 0
{
}
void ISR_Ep2pflag( void ) interrupt 0
{
}
void ISR_Ep4pflag( void ) interrupt 0
{
}
void ISR_Ep6pflag( void ) interrupt 0
{
}
void ISR_Ep8pflag( void ) interrupt 0
{
}
void ISR_Ep2eflag( void ) interrupt 0
{
}
void ISR_Ep4eflag( void ) interrupt 0
{
}
void ISR_Ep6eflag( void ) interrupt 0
{
}
void ISR_Ep8eflag( void ) interrupt 0
{
}
void ISR_Ep2fflag( void ) interrupt 0
{
}
void ISR_Ep4fflag( void ) interrupt 0
{
}
void ISR_Ep6fflag( void ) interrupt 0
{
}
void ISR_Ep8fflag( void ) interrupt 0
{
}
void ISR_GpifComplete( void ) interrupt 0
{
}
void ISR_GpifWaveform( void ) interrupt 0
{
}

// ...debug LEDs: accessed via movx reads only ( through CPLD )
// it may be worth noting here that the default monitor loads at 0xC000
xdata volatile const BYTE LED0_ON  _at_ 0x8000;
xdata volatile const BYTE LED0_OFF _at_ 0x8100;
xdata volatile const BYTE LED1_ON  _at_ 0x9000;
xdata volatile const BYTE LED1_OFF _at_ 0x9100;
xdata volatile const BYTE LED2_ON  _at_ 0xA000;
xdata volatile const BYTE LED2_OFF _at_ 0xA100;
xdata volatile const BYTE LED3_ON  _at_ 0xB000;
xdata volatile const BYTE LED3_OFF _at_ 0xB100;
// use this global variable when (de)asserting debug LEDs...
BYTE xdata ledX_rdvar = 0x00;
BYTE xdata LED_State = 0;
void LED_Off (BYTE LED_Mask)
{
	if (LED_Mask & bmBIT0)
	{
		ledX_rdvar = LED0_OFF;
		LED_State &= ~bmBIT0;
	}
	if (LED_Mask & bmBIT1)
	{
		ledX_rdvar = LED1_OFF;
		LED_State &= ~bmBIT1;
	}
	if (LED_Mask & bmBIT2)
	{
		ledX_rdvar = LED2_OFF;
		LED_State &= ~bmBIT2;
	}
	if (LED_Mask & bmBIT3)
	{
		ledX_rdvar = LED3_OFF;
		LED_State &= ~bmBIT3;
	}
}

void LED_On (BYTE LED_Mask)
{
	if (LED_Mask & bmBIT0)
	{
		ledX_rdvar = LED0_ON;
		LED_State |= bmBIT0;
	}
	if (LED_Mask & bmBIT1)
	{
		ledX_rdvar = LED1_ON;
		LED_State |= bmBIT1;
	}
	if (LED_Mask & bmBIT2)
	{
		ledX_rdvar = LED2_ON;
		LED_State |= bmBIT2;
	}
	if (LED_Mask & bmBIT3)
	{
		ledX_rdvar = LED3_ON;
		LED_State |= bmBIT3;
	}
}


